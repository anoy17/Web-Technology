
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Data</title>
	<style>
		table, thead, tbody, tr, th, td {
		border: 1px solid black;
		}
	</style>
</head>
<body>

<?php
$a=$_POST['Firstname'];
$b=$_POST['Lastname'];
$c=$_POST['Gender'] ;
$d=$_POST['Division'] ;

echo "<table border='1'>";
echo "<tr>";
echo "<th>Firstname </th>";
echo "<th>Lastname </th>";
echo "<th>Gender </th>";
echo "<th>Division </th>";
echo "</tr>";
echo "<tr>";
echo "<td>$a</td>";
echo "<td>$b</td>";
echo "<td>$c</td>";
echo "<td>$d</td>";
echo "</tr>";
	

echo "</table>";
?>

	
</body>
</html>